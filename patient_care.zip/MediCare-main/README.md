# Welcome to your Madicare 
## Project info

**URL**: https://preview--vital-track-pro.lovable.app/dashboard
